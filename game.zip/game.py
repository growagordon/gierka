import random

def gra_zgadnij_liczbe():
    print("Witaj w grze 'Zgadnij liczbę'!")
    print("Wylosowałem liczbę z zakresu od 1 do 100. Spróbuj ją odgadnąć.")
    
    wylosowana_liczba = random.randint(1, 100)
    proby = 0
    
    while True:
        try:
            strzal = int(input("Twoja propozycja: "))
            proby += 1
            
            if strzal < wylosowana_liczba:
                print("Za mało! Spróbuj podać większą liczbę.")
            elif strzal > wylosowana_liczba:
                print("Za dużo! Spróbuj podać mniejszą liczbę.")
            else:
                print(f"Gratulacje! Odgadłeś liczbę {wylosowana_liczba} w {proby} próbach!")
                break
        except ValueError:
            print("To nie jest poprawna liczba! Wpisz całkowitą liczbę.")

if __name__ == "__main__":
    gra_zgadnij_liczbe()
